// Ganti nama tamu dari URL
const urlParams = new URLSearchParams(window.location.search);
const guest = urlParams.get('to');
if (guest) {
  document.getElementById('guestName').textContent = guest;
}

// Autoplay musik (jika diizinkan browser)
window.addEventListener('click', () => {
  const audio = document.getElementById('music');
  if (audio.paused) {
    audio.play();
  }
}, { once: true });
